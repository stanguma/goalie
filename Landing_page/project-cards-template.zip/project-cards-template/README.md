Project Cards Template
=========

A portfolio template with expandable projects and a full-page navigation inspired by Primer app.

[Article on CodyHouse](http://codyhouse.co/gem/project-cards-template/)

[Demo](https://codyhouse.co/demo/project-cards-template/index.html)

Images: [Unsplash](https://unsplash.com/)
 
[Terms](http://codyhouse.co/terms/)
